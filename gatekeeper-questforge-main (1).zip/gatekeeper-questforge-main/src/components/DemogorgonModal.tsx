import { motion, AnimatePresence } from "framer-motion";
import { useEffect } from "react";

interface DemogorgonModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const DemogorgonModal = ({ isOpen, onClose }: DemogorgonModalProps) => {
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        onClose();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [isOpen, onClose]);

  function getPetalPath(index: number): string {
    const angle = (index * 60) - 90;
    const nextAngle = ((index + 1) * 60) - 90;
    const rad1 = (angle * Math.PI) / 180;
    const rad2 = (nextAngle * Math.PI) / 180;
    
    const x1 = 50 + 70 * Math.cos(rad1);
    const y1 = 50 + 70 * Math.sin(rad1);
    const x2 = 50 + 70 * Math.cos(rad2);
    const y2 = 50 + 70 * Math.sin(rad2);
    
    return `polygon(50% 50%, ${x1}% ${y1}%, ${x2}% ${y2}%)`;
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Dark backdrop */}
          <motion.div 
            className="absolute inset-0 bg-black/95"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
          
          {/* Demogorgon mouth petals */}
          <div className="absolute inset-0 overflow-hidden">
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <motion.div
                key={i}
                initial={{ clipPath: "polygon(50% 50%, 50% 50%, 50% 50%)", opacity: 0 }}
                animate={{ 
                  clipPath: getPetalPath(i), 
                  opacity: 1,
                  transition: { duration: 0.8, ease: "easeOut", delay: i * 0.05 }
                }}
                exit={{ 
                  clipPath: "polygon(50% 50%, 50% 50%, 50% 50%)", 
                  opacity: 0,
                  transition: { duration: 0.5, ease: "easeIn", delay: (5 - i) * 0.03 }
                }}
                className="absolute inset-0"
                style={{
                  background: `linear-gradient(${i * 60}deg, 
                    hsl(0, 70%, 15%) 0%, 
                    hsl(0, 80%, 25%) 30%,
                    hsl(0, 90%, 20%) 60%,
                    hsl(0, 70%, 10%) 100%)`,
                  boxShadow: "inset 0 0 50px rgba(139, 0, 0, 0.8)",
                }}
              />
            ))}
            
            {/* Fleshy texture overlay */}
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <motion.div
                key={`vein-${i}`}
                initial={{ clipPath: "polygon(50% 50%, 50% 50%, 50% 50%)", opacity: 0 }}
                animate={{ 
                  clipPath: getPetalPath(i), 
                  opacity: 1,
                  transition: { duration: 0.8, ease: "easeOut", delay: i * 0.05 }
                }}
                exit={{ 
                  clipPath: "polygon(50% 50%, 50% 50%, 50% 50%)", 
                  opacity: 0,
                  transition: { duration: 0.5, ease: "easeIn", delay: (5 - i) * 0.03 }
                }}
                className="absolute inset-0 pointer-events-none"
                style={{
                  background: `radial-gradient(ellipse at ${50 + 20 * Math.cos((i * 60 - 60) * Math.PI / 180)}% ${50 + 20 * Math.sin((i * 60 - 60) * Math.PI / 180)}%, 
                    rgba(180, 0, 0, 0.4) 0%, 
                    transparent 40%)`,
                }}
              />
            ))}
          </div>

          {/* Center content - the message inside the mouth */}
          <motion.div
            className="relative z-10 text-center px-8"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ 
              scale: 1, 
              opacity: 1,
              transition: { delay: 0.6, duration: 0.5, ease: "easeOut" }
            }}
            exit={{ scale: 0, opacity: 0, transition: { duration: 0.3 } }}
          >
            {/* Glowing orb behind text */}
            <motion.div
              className="absolute inset-0 -z-10"
              style={{
                background: "radial-gradient(circle, rgba(255, 50, 50, 0.3) 0%, transparent 70%)",
                filter: "blur(40px)",
              }}
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 0.8, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
            
            {/* Main text with trembling effect */}
            <motion.h1
              className="text-4xl md:text-6xl font-bold tracking-wider"
              style={{
                fontFamily: "'Benguiat', 'ITC Benguiat', serif",
                color: "#ff1a1a",
                textShadow: `
                  0 0 10px #ff0000,
                  0 0 20px #ff0000,
                  0 0 40px #ff0000,
                  0 0 80px #cc0000,
                  0 0 120px #990000
                `,
              }}
              animate={{
                x: [0, -2, 2, -1, 1, 0],
                y: [0, 1, -1, 2, -2, 0],
              }}
              transition={{
                duration: 0.3,
                repeat: Infinity,
                repeatType: "loop",
              }}
            >
              YOUR QUEST
              <br />
              HAS BEEN CREATED
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              className="mt-6 text-red-400 text-lg tracking-widest uppercase"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0, transition: { delay: 1 } }}
              style={{
                textShadow: "0 0 10px rgba(255, 0, 0, 0.5)",
              }}
            >
              The Upside Down awaits...
            </motion.p>
          </motion.div>

          {/* Particle effects */}
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={`particle-${i}`}
              className="absolute w-1 h-1 bg-red-500 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              initial={{ opacity: 0, scale: 0 }}
              animate={{
                opacity: [0, 1, 0],
                scale: [0, 1.5, 0],
                y: [0, -100 - Math.random() * 100],
              }}
              transition={{
                duration: 2 + Math.random() * 2,
                delay: 0.5 + Math.random() * 0.5,
                repeat: Infinity,
                repeatDelay: Math.random() * 2,
              }}
            />
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default DemogorgonModal;
