import { useState } from "react";
import { motion } from "framer-motion";
import { MapPin, Calendar, Clock, Users } from "lucide-react";
import { useNavigate } from "react-router-dom";
import DemogorgonModal from "./DemogorgonModal";

const activityTypes = ["Food", "Study", "Adventure"];
const vibeTags = ["Chill", "Active", "Late Night", "Social", "Creative", "Outdoors"];

const QuestForm = () => {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    activityType: "",
    date: "",
    time: "",
    location: "",
    partySize: 4,
    vibes: [] as string[],
  });

  const handleVibeToggle = (vibe: string) => {
    setFormData(prev => ({
      ...prev,
      vibes: prev.vibes.includes(vibe)
        ? prev.vibes.filter(v => v !== vibe)
        : [...prev.vibes, vibe]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsModalOpen(true);
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    navigate("/");
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-2xl mx-auto"
      >
        {/* Glassmorphism Card */}
        <div className="relative p-8 rounded-2xl bg-black/40 backdrop-blur-xl border border-cyan-500/50 shadow-[0_0_30px_rgba(0,255,255,0.3),inset_0_0_30px_rgba(0,255,255,0.1)]">
          {/* Neon border glow effect */}
          <div className="absolute inset-0 rounded-2xl pointer-events-none">
            <div className="absolute inset-0 rounded-2xl border-2 border-cyan-400/60 shadow-[0_0_15px_rgba(0,255,255,0.5)]" />
          </div>

          {/* Title */}
          <motion.h1
            className="text-center text-4xl md:text-5xl font-bold mb-8 tracking-wider"
            style={{
              fontFamily: "'Benguiat', 'ITC Benguiat', serif",
              color: "#ff1a1a",
              textShadow: `
                0 0 10px #ff0000,
                0 0 20px #ff0000,
                0 0 40px #ff0000,
                0 0 80px #cc0000
              `,
            }}
            animate={{
              textShadow: [
                "0 0 10px #ff0000, 0 0 20px #ff0000, 0 0 40px #ff0000, 0 0 80px #cc0000",
                "0 0 15px #ff0000, 0 0 30px #ff0000, 0 0 60px #ff0000, 0 0 100px #cc0000",
                "0 0 10px #ff0000, 0 0 20px #ff0000, 0 0 40px #ff0000, 0 0 80px #cc0000",
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            CREATE YOUR QUEST
          </motion.h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Quest Title */}
            <div className="space-y-2">
              <label className="text-cyan-300 text-sm font-medium tracking-wide">QUEST TITLE</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full px-4 py-3 bg-black/50 border-2 border-cyan-500/50 rounded-lg text-white placeholder-cyan-700 focus:outline-none focus:border-cyan-400 focus:shadow-[0_0_20px_rgba(0,255,255,0.4)] transition-all duration-300"
                placeholder="Enter your quest title..."
              />
            </div>

            {/* Activity Type */}
            <div className="space-y-2">
              <label className="text-cyan-300 text-sm font-medium tracking-wide">ACTIVITY TYPE</label>
              <select
                value={formData.activityType}
                onChange={(e) => setFormData(prev => ({ ...prev, activityType: e.target.value }))}
                className="w-full px-4 py-3 bg-black/50 border-2 border-cyan-500/50 rounded-lg text-white focus:outline-none focus:border-cyan-400 focus:shadow-[0_0_20px_rgba(0,255,255,0.4)] transition-all duration-300 appearance-none cursor-pointer"
              >
                <option value="" className="bg-gray-900">Select activity...</option>
                {activityTypes.map(type => (
                  <option key={type} value={type} className="bg-gray-900">{type}</option>
                ))}
              </select>
            </div>

            {/* When & Time */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-cyan-300 text-sm font-medium tracking-wide flex items-center gap-2">
                  <Calendar className="w-4 h-4" /> WHEN
                </label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                  className="w-full px-4 py-3 bg-black/50 border-2 border-cyan-500/50 rounded-lg text-white focus:outline-none focus:border-cyan-400 focus:shadow-[0_0_20px_rgba(0,255,255,0.4)] transition-all duration-300 [color-scheme:dark]"
                />
              </div>
              <div className="space-y-2">
                <label className="text-cyan-300 text-sm font-medium tracking-wide flex items-center gap-2">
                  <Clock className="w-4 h-4" /> TIME
                </label>
                <input
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData(prev => ({ ...prev, time: e.target.value }))}
                  className="w-full px-4 py-3 bg-black/50 border-2 border-cyan-500/50 rounded-lg text-white focus:outline-none focus:border-cyan-400 focus:shadow-[0_0_20px_rgba(0,255,255,0.4)] transition-all duration-300 [color-scheme:dark]"
                />
              </div>
            </div>

            {/* Where */}
            <div className="space-y-2">
              <label className="text-cyan-300 text-sm font-medium tracking-wide flex items-center gap-2">
                <MapPin className="w-4 h-4" /> WHERE
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                className="w-full px-4 py-3 bg-black/50 border-2 border-cyan-500/50 rounded-lg text-white placeholder-cyan-700 focus:outline-none focus:border-cyan-400 focus:shadow-[0_0_20px_rgba(0,255,255,0.4)] transition-all duration-300"
                placeholder="Enter location..."
              />
            </div>

            {/* Party Size */}
            <div className="space-y-4">
              <label className="text-cyan-300 text-sm font-medium tracking-wide flex items-center gap-2">
                <Users className="w-4 h-4" /> PARTY SIZE: <span className="text-cyan-100 font-bold">{formData.partySize}</span>
              </label>
              <div className="relative">
                <input
                  type="range"
                  min="2"
                  max="10"
                  value={formData.partySize}
                  onChange={(e) => setFormData(prev => ({ ...prev, partySize: parseInt(e.target.value) }))}
                  className="w-full h-2 bg-black/50 rounded-lg appearance-none cursor-pointer slider-neon"
                  style={{
                    background: `linear-gradient(to right, #00ffff ${((formData.partySize - 2) / 8) * 100}%, rgba(0,0,0,0.5) ${((formData.partySize - 2) / 8) * 100}%)`,
                  }}
                />
                <div className="flex justify-between text-xs text-cyan-600 mt-1">
                  <span>2</span>
                  <span>10</span>
                </div>
              </div>
            </div>

            {/* Vibe Tags */}
            <div className="space-y-3">
              <label className="text-cyan-300 text-sm font-medium tracking-wide">VIBE TAGS</label>
              <div className="flex flex-wrap gap-2">
                {vibeTags.map(vibe => (
                  <motion.button
                    key={vibe}
                    type="button"
                    onClick={() => handleVibeToggle(vibe)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                      formData.vibes.includes(vibe)
                        ? "bg-cyan-500/30 border-2 border-cyan-400 text-cyan-100 shadow-[0_0_15px_rgba(0,255,255,0.5)]"
                        : "bg-black/30 border-2 border-cyan-700/50 text-cyan-500 hover:border-cyan-500"
                    }`}
                  >
                    {vibe}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full mt-8 py-4 rounded-xl text-xl font-bold tracking-widest text-cyan-100 uppercase transition-all duration-300 relative overflow-hidden group"
              style={{
                background: "linear-gradient(135deg, rgba(0,255,255,0.2) 0%, rgba(0,200,255,0.1) 100%)",
                border: "2px solid rgba(0,255,255,0.6)",
                boxShadow: "0 0 30px rgba(0,255,255,0.4), inset 0 0 30px rgba(0,255,255,0.1)",
              }}
            >
              {/* Animated glow effect */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent"
                animate={{
                  x: ["-100%", "100%"],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatDelay: 1,
                }}
              />
              <span className="relative z-10 drop-shadow-[0_0_10px_rgba(0,255,255,0.8)]">
                OPEN THE GATE
              </span>
            </motion.button>
          </form>
        </div>
      </motion.div>

      <DemogorgonModal isOpen={isModalOpen} onClose={handleModalClose} />

      <style>{`
        .slider-neon::-webkit-slider-thumb {
          appearance: none;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #00ffff;
          cursor: pointer;
          box-shadow: 0 0 15px #00ffff, 0 0 30px #00ffff;
        }
        .slider-neon::-moz-range-thumb {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #00ffff;
          cursor: pointer;
          box-shadow: 0 0 15px #00ffff, 0 0 30px #00ffff;
          border: none;
        }
      `}</style>
    </>
  );
};

export default QuestForm;
