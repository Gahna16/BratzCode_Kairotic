import { Link } from "react-router-dom";
import { Award, ArrowRight } from "lucide-react";
import nightMapBg from "@/assets/night-map-bg.png";

const Index = () => {
  return (
    <div
      className="min-h-screen w-full bg-cover bg-center bg-no-repeat relative overflow-hidden"
      style={{ backgroundImage: `url(${nightMapBg})` }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-background/50" />

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4">
        {/* Main Title */}
        <h1 className="neon-title text-5xl md:text-7xl lg:text-8xl mb-6 text-center">
          DOWNSIDE-UP
        </h1>
        
        <p className="neon-yellow-text font-body text-sm md:text-lg tracking-widest uppercase mb-12 text-center">
          Ditch the scroll. Unlock the Quest.
        </p>

        {/* Navigation Card */}
        <Link
          to="/badges"
          className="glass-card rounded-xl px-8 py-6 flex items-center gap-4 group cursor-pointer hover:border-neon-yellow transition-all"
        >
          <Award className="w-8 h-8 text-neon-yellow icon-pulse" />
          <div className="flex flex-col">
            <span className="font-display text-xl tracking-wider text-foreground">
              BADGES
            </span>
            <span className="font-body text-sm text-muted-foreground tracking-wide">
              Assign badges to your crew
            </span>
          </div>
          <ArrowRight className="w-6 h-6 text-primary group-hover:translate-x-2 transition-transform" />
        </Link>
      </div>
    </div>
  );
};

export default Index;
