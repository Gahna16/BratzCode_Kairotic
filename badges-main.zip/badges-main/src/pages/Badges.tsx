import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { ProfileCard } from "@/components/ProfileCard";
import nightMapBg from "@/assets/night-map-bg.png";

interface Profile {
  id: number;
  name: string;
}

const initialProfiles: Profile[] = [
  { id: 1, name: "ALEX" },
  { id: 2, name: "MAYA" },
  { id: 3, name: "JORDAN" },
];

const Badges = () => {
  const [profiles, setProfiles] = useState<Profile[]>(initialProfiles);

  const handleRemoveProfile = (id: number) => {
    setProfiles((prev) => prev.filter((p) => p.id !== id));
  };

  return (
    <div
      className="min-h-screen w-full bg-cover bg-center bg-no-repeat relative overflow-hidden"
      style={{ backgroundImage: `url(${nightMapBg})` }}
    >
      {/* Dark overlay for better readability */}
      <div className="absolute inset-0 bg-background/40" />

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Navigation */}
        <nav className="p-6">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-foreground/80 hover:text-primary transition-colors group"
          >
            <ArrowLeft className="w-6 h-6 group-hover:-translate-x-1 transition-transform" />
            <span className="font-body text-sm tracking-wide">Back to Home</span>
          </Link>
        </nav>

        {/* Header */}
        <header className="text-center pt-4 pb-12">
          <h1 className="neon-title text-4xl md:text-6xl lg:text-7xl mb-4">
            DOWNSIDE-UP
          </h1>
          <p className="neon-yellow-text font-body text-sm md:text-base tracking-widest uppercase">
            Ditch the scroll. Unlock the Quest.
          </p>
        </header>

        {/* Profile Cards */}
        <main className="flex-1 flex items-center justify-center px-4 pb-12">
          {profiles.length > 0 ? (
            <div className="flex flex-wrap justify-center gap-8">
              {profiles.map((profile, index) => (
                <ProfileCard
                  key={profile.id}
                  name={profile.name}
                  avatarIndex={index % 3}
                  onRemove={() => handleRemoveProfile(profile.id)}
                />
              ))}
            </div>
          ) : (
            <div className="glass-card rounded-xl p-8 text-center animate-fade-in">
              <p className="font-body text-muted-foreground tracking-wide">
                No profiles remaining. All quests have been assigned!
              </p>
              <Link
                to="/"
                className="mt-4 inline-block px-6 py-2 rounded-lg bg-primary/20 border border-primary text-primary font-body text-sm tracking-wide hover:bg-primary/30 transition-all"
              >
                Return Home
              </Link>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default Badges;
