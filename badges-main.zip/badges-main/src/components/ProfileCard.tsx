import { useState } from "react";
import { Smile, Heart, Compass, Crown, Cookie, Map, X, ChevronDown, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Badge {
  name: string;
  icon: React.ReactNode;
  color: string;
}

const badges: Record<string, Badge> = {
  comedian: {
    name: "The Comedian",
    icon: <Smile className="w-6 h-6" />,
    color: "text-neon-yellow",
  },
  mom: {
    name: "The Mom",
    icon: <Heart className="w-6 h-6" />,
    color: "text-neon-red",
  },
  kindcore: {
    name: "Kind Core",
    icon: <Heart className="w-6 h-6" />,
    color: "text-pink-400",
  },
  navigator: {
    name: "The Navigator",
    icon: <Compass className="w-6 h-6" />,
    color: "text-cyan-400",
  },
  leader: {
    name: "Quest Leader",
    icon: <Crown className="w-6 h-6" />,
    color: "text-neon-yellow",
  },
  snackmaster: {
    name: "Snack Master",
    icon: <Cookie className="w-6 h-6" />,
    color: "text-orange-400",
  },
};

interface ProfileCardProps {
  name: string;
  avatarIndex: number;
  onRemove: () => void;
}

export const ProfileCard = ({ name, avatarIndex, onRemove }: ProfileCardProps) => {
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);
  const [isRemoving, setIsRemoving] = useState(false);

  const handleNotInterested = () => {
    setIsRemoving(true);
    setTimeout(() => {
      onRemove();
    }, 500);
  };

  const handleSelectBadge = (badgeKey: string) => {
    setSelectedBadge(badges[badgeKey]);
  };

  const avatarColors = [
    "from-neon-red to-orange-500",
    "from-neon-yellow to-amber-500",
    "from-cyan-400 to-blue-500",
  ];

  return (
    <div
      className={`glass-card rounded-xl p-6 w-64 flex flex-col items-center gap-4 ${
        isRemoving ? "fade-out" : "animate-scale-in"
      }`}
    >
      {/* Avatar */}
      <div
        className={`w-20 h-20 rounded-full bg-gradient-to-br ${avatarColors[avatarIndex]} flex items-center justify-center shadow-lg`}
        style={{
          boxShadow: `0 0 20px hsla(${avatarIndex === 0 ? "0" : avatarIndex === 1 ? "50" : "190"}, 100%, 50%, 0.4)`,
        }}
      >
        <User className="w-10 h-10 text-white/90" />
      </div>

      {/* Name */}
      <h3 className="font-display text-lg tracking-wider text-foreground">{name}</h3>

      {/* Badge Display */}
      {selectedBadge && (
        <div className="flex flex-col items-center gap-2 animate-fade-in">
          <div className={`${selectedBadge.color} icon-pulse`}>
            {selectedBadge.icon}
          </div>
          <span className={`text-sm font-body tracking-wide ${selectedBadge.color}`}>
            {selectedBadge.name}
          </span>
        </div>
      )}

      {/* Dropdown Menu */}
      <DropdownMenu>
        <DropdownMenuTrigger className="mt-2 px-4 py-2 rounded-lg bg-muted/50 border border-primary/50 text-foreground font-body text-sm tracking-wide flex items-center gap-2 hover:border-primary hover:bg-muted/70 transition-all focus:outline-none focus:ring-2 focus:ring-primary/50">
          {selectedBadge ? "Change Badge" : "Assign Badge"}
          <ChevronDown className="w-4 h-4" />
        </DropdownMenuTrigger>
        <DropdownMenuContent className="bg-popover border-primary/50 backdrop-blur-lg z-50">
          {Object.entries(badges).map(([key, badge]) => (
            <DropdownMenuItem
              key={key}
              onClick={() => handleSelectBadge(key)}
              className={`flex items-center gap-3 cursor-pointer hover:bg-primary/20 focus:bg-primary/20 ${badge.color}`}
            >
              <span className="icon-pulse">{badge.icon}</span>
              <span className="font-body">{badge.name}</span>
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator className="bg-primary/30" />
          <DropdownMenuItem
            onClick={handleNotInterested}
            className="flex items-center gap-3 cursor-pointer text-muted-foreground hover:bg-destructive/20 hover:text-destructive focus:bg-destructive/20 focus:text-destructive"
          >
            <X className="w-5 h-5" />
            <span className="font-body">Not Interested</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};
