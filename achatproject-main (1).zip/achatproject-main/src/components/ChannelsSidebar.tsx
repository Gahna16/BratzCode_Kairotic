import { Radio } from "lucide-react";

interface Channel {
  id: string;
  name: string;
  active?: boolean;
}

interface ChannelsSidebarProps {
  channels: Channel[];
  activeChannel: string;
  onChannelSelect: (id: string) => void;
}

const ChannelsSidebar = ({ channels, activeChannel, onChannelSelect }: ChannelsSidebarProps) => {
  return (
    <div className="glass-panel neon-border-yellow w-72 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-neon-yellow/20">
        <div className="flex items-center gap-2">
          <Radio className="w-5 h-5 text-neon-red animate-pulse-glow" />
          <h2 className="font-display text-sm font-bold tracking-wider neon-text-red">
            ACTIVE CHANNELS
          </h2>
        </div>
      </div>

      {/* Channel List */}
      <div className="flex-1 py-2">
        {channels.map((channel) => (
          <div
            key={channel.id}
            onClick={() => onChannelSelect(channel.id)}
            className={`channel-item ${activeChannel === channel.id ? 'active' : ''}`}
          >
            <span className={`font-display text-sm tracking-wide ${
              activeChannel === channel.id ? 'neon-text-blue' : 'neon-text-yellow'
            }`}>
              {channel.name}
            </span>
          </div>
        ))}
      </div>

      {/* Footer with signal indicator */}
      <div className="p-4 border-t border-neon-yellow/20">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
          <span>SIGNAL STRONG</span>
        </div>
      </div>
    </div>
  );
};

export default ChannelsSidebar;
