import { useState } from "react";
import { Plus, Users } from "lucide-react";

interface Message {
  id: string;
  sender: string;
  text: string;
  isUser?: boolean;
  showSentPill?: boolean;
}

interface ChatWindowProps {
  channelName: string;
  playerCount: string;
  initialMessages: Message[];
}

const ChatWindow = ({ channelName, playerCount, initialMessages }: ChatWindowProps) => {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputValue, setInputValue] = useState("");

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      sender: "YOU",
      text: inputValue,
      isUser: true,
      showSentPill: true,
    };

    setMessages([...messages, newMessage]);
    setInputValue("");

    // Remove the pill after 3 seconds
    setTimeout(() => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === newMessage.id ? { ...msg, showSentPill: false } : msg
        )
      );
    }, 3000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getSenderColor = (sender: string) => {
    switch (sender.toUpperCase()) {
      case "STEVE":
        return "text-neon-red";
      case "DUSTIN":
        return "text-neon-green";
      case "MIKE":
        return "text-neon-purple";
      case "YOU":
        return "text-neon-blue";
      default:
        return "text-neon-yellow";
    }
  };

  return (
    <div className="glass-panel neon-border-blue flex-1 flex flex-col max-w-2xl">
      {/* Header */}
      <div className="p-4 border-b border-neon-blue/20">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-sm font-bold tracking-wider neon-text-blue">
            {channelName}
          </h2>
          <div className="flex items-center gap-2 text-sm">
            <Users className="w-4 h-4 text-neon-blue" />
            <span className="neon-text-blue">{playerCount}</span>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 p-4 space-y-4 overflow-y-auto min-h-[300px]">
        {messages.map((message) => (
          <div key={message.id} className="flex items-start gap-2">
            <span className={`font-display font-bold ${getSenderColor(message.sender)}`}>
              {message.sender}:
            </span>
            <span className="text-foreground/90">{message.text}</span>
            {message.showSentPill && (
              <span className="message-sent-pill">MESSAGE SENT</span>
            )}
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="p-4 border-t border-neon-blue/20">
        <div className="relative">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Send a transmission..."
            className="w-full bg-background/50 border-2 border-neon-blue/50 rounded-lg px-4 py-3 pr-12 
                       text-foreground placeholder:text-muted-foreground font-mono
                       focus:outline-none focus:border-neon-blue focus:shadow-[0_0_15px_hsl(var(--neon-blue)/0.3)]
                       transition-all duration-300"
          />
          <button
            onClick={handleSendMessage}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 
                       flex items-center justify-center rounded-md
                       bg-neon-blue/20 hover:bg-neon-blue/40 
                       border border-neon-blue/50 hover:border-neon-blue
                       transition-all duration-300 group"
          >
            <Plus className="w-5 h-5 text-neon-blue group-hover:scale-110 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;
