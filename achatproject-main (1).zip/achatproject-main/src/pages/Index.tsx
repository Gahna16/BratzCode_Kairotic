import { useState } from "react";
import ChannelsSidebar from "@/components/ChannelsSidebar";
import ChatWindow from "@/components/ChatWindow";
import campusBackground from "@/assets/campus-background.png";

const channels = [
  { id: "pizza", name: "MIDNIGHT PIZZA RUN" },
  { id: "campfire", name: "BEACH CAMPFIRE" },
  { id: "arena", name: "ARENA CLASHERS" },
];

const initialMessages = [
  { id: "1", sender: "STEVE", text: "when are you guys coming?" },
  { id: "2", sender: "DUSTIN", text: "pulling up in 5" },
  { id: "3", sender: "MIKE", text: "yeah i am on my way as well" },
  { id: "4", sender: "STEVE", text: "cool" },
  { id: "5", sender: "DUSTIN", text: "steve stop yapping and come asap" },
];

const Index = () => {
  const [activeChannel, setActiveChannel] = useState("arena");

  return (
    <div 
      className="min-h-screen w-full relative overflow-hidden"
      style={{
        backgroundImage: `url(${campusBackground})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
      }}
    >
      {/* Atmospheric overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-transparent to-background/60" />
      <div className="absolute inset-0 bg-gradient-to-r from-neon-purple/10 via-transparent to-neon-red/10" />
      
      {/* Scanline effect */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.03]"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.3) 2px, rgba(0,0,0,0.3) 4px)',
        }}
      />

      {/* Main content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-6 gap-6">
        <ChannelsSidebar
          channels={channels}
          activeChannel={activeChannel}
          onChannelSelect={setActiveChannel}
        />
        <ChatWindow
          channelName="ARENA CLASHERS"
          playerCount="3/5 Players"
          initialMessages={initialMessages}
        />
      </div>

      {/* Corner decorations */}
      <div className="absolute top-4 left-4 w-16 h-16 border-l-2 border-t-2 border-neon-red/30" />
      <div className="absolute top-4 right-4 w-16 h-16 border-r-2 border-t-2 border-neon-blue/30" />
      <div className="absolute bottom-4 left-4 w-16 h-16 border-l-2 border-b-2 border-neon-yellow/30" />
      <div className="absolute bottom-4 right-4 w-16 h-16 border-r-2 border-b-2 border-neon-green/30" />
    </div>
  );
};

export default Index;
