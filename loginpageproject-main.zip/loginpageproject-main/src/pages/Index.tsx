import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { EmberParticles } from "@/components/EmberParticles";
import { LoginForm } from "@/components/LoginForm";
import { RiftTransition } from "@/components/RiftTransition";
import { Dashboard } from "@/components/Dashboard";
import upsideDownBg from "@/assets/upside-down-bg.jpeg";

const Index = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showRift, setShowRift] = useState(false);

  const handleLogin = () => {
    setShowRift(true);
  };

  const handleRiftComplete = () => {
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setShowRift(false);
  };

  return (
    <div className="relative min-h-screen overflow-hidden">
      <AnimatePresence mode="wait">
        {!isLoggedIn ? (
          <motion.div
            key="login"
            className="relative min-h-screen flex flex-col items-center justify-center"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* Background Image */}
            <div
              className="absolute inset-0 bg-cover bg-center bg-no-repeat"
              style={{
                backgroundImage: `url(${upsideDownBg})`,
              }}
            />

            {/* Dark Overlay */}
            <div className="absolute inset-0 bg-background/60" />

            {/* Vignette Effect */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                background:
                  "radial-gradient(ellipse at center, transparent 0%, hsl(260 30% 3% / 0.7) 70%, hsl(260 30% 3% / 0.95) 100%)",
              }}
            />

            {/* Ember Particles */}
            <EmberParticles />

            {/* Main Content */}
            <div className="relative z-20 flex flex-col items-center w-full px-4">
              {/* Title */}
              <motion.h1
                className="text-6xl md:text-8xl font-display font-black text-primary title-glow mb-4 text-center tracking-wider"
                initial={{ opacity: 0, y: -30, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{
                  duration: 1,
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                DOWNSIDE-UP
              </motion.h1>

              {/* Subtitle */}
              <motion.p
                className="text-lg md:text-xl text-muted-foreground font-body mb-12 text-center max-w-md"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                Where the journey begins... and reality ends
              </motion.p>

              {/* Login Form */}
              <LoginForm onLogin={handleLogin} />
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Dashboard onLogout={handleLogout} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Rift Transition Overlay */}
      <RiftTransition isOpen={showRift && !isLoggedIn} onComplete={handleRiftComplete}>
        <div className="h-full bg-background" />
      </RiftTransition>
    </div>
  );
};

export default Index;
