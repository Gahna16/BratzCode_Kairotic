import { forwardRef, InputHTMLAttributes } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface GlowingInputProps extends InputHTMLAttributes<HTMLInputElement> {
  icon?: React.ReactNode;
  label?: string;
}

export const GlowingInput = forwardRef<HTMLInputElement, GlowingInputProps>(
  ({ className, icon, label, ...props }, ref) => {
    return (
      <motion.div
        className="relative w-full"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        {label && (
          <label className="block text-sm font-medium text-muted-foreground mb-2 font-body tracking-wide">
            {label}
          </label>
        )}
        <div className="relative group">
          {icon && (
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-secondary icon-glow z-10">
              {icon}
            </div>
          )}
          <input
            ref={ref}
            className={cn(
              "w-full h-14 rounded-lg glow-input text-foreground font-body",
              "focus:outline-none focus:ring-0",
              "transition-all duration-300",
              icon ? "pl-12 pr-4" : "px-4",
              className
            )}
            {...props}
          />
          <motion.div
            className="absolute inset-0 rounded-lg pointer-events-none"
            initial={false}
            whileHover={{
              boxShadow: "0 0 25px hsl(25 100% 55% / 0.4)",
            }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </motion.div>
    );
  }
);

GlowingInput.displayName = "GlowingInput";
