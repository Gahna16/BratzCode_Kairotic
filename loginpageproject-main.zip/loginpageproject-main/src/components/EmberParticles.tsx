import { useEffect, useState } from "react";
import { motion } from "framer-motion";

interface Ember {
  id: number;
  x: number;
  delay: number;
  duration: number;
  size: number;
}

export const EmberParticles = () => {
  const [embers, setEmbers] = useState<Ember[]>([]);

  useEffect(() => {
    const generateEmbers = () => {
      const newEmbers: Ember[] = [];
      for (let i = 0; i < 50; i++) {
        newEmbers.push({
          id: i,
          x: Math.random() * 100,
          delay: Math.random() * 10,
          duration: 8 + Math.random() * 12,
          size: 2 + Math.random() * 6,
        });
      }
      setEmbers(newEmbers);
    };

    generateEmbers();
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-10">
      {embers.map((ember) => (
        <motion.div
          key={ember.id}
          className="absolute rounded-full"
          style={{
            left: `${ember.x}%`,
            bottom: "-20px",
            width: ember.size,
            height: ember.size,
            background: `radial-gradient(circle, hsl(25 100% 60%) 0%, hsl(0 80% 50% / 0.5) 50%, transparent 70%)`,
            boxShadow: `0 0 ${ember.size * 2}px hsl(25 100% 55% / 0.6)`,
          }}
          animate={{
            y: [0, -window.innerHeight - 100],
            x: [0, (Math.random() - 0.5) * 100],
            opacity: [0, 1, 1, 0],
            scale: [0.5, 1, 0.8, 0],
          }}
          transition={{
            duration: ember.duration,
            delay: ember.delay,
            repeat: Infinity,
            ease: "linear",
          }}
        />
      ))}
    </div>
  );
};
