import { useState } from "react";
import { motion } from "framer-motion";
import { IdCard, Mail, KeyRound } from "lucide-react";
import { GlowingInput } from "./GlowingInput";
import { GoogleSignInButton } from "./GoogleSignInButton";

interface LoginFormProps {
  onLogin: () => void;
}

export const LoginForm = ({ onLogin }: LoginFormProps) => {
  const [registrationNumber, setRegistrationNumber] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate login
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 1500);
  };

  const handleGoogleSignIn = () => {
    setIsLoading(true);
    // Simulate Google sign-in
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 2000);
  };

  return (
    <motion.div
      className="glass-card rounded-2xl p-8 w-full max-w-md mx-4"
      initial={{ opacity: 0, y: 30, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
    >
      {/* Form Header */}
      <motion.div
        className="text-center mb-8"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <h2 className="text-2xl font-display font-bold text-foreground mb-2">
          Enter the <span className="text-gradient-fire">Quest</span>
        </h2>
        <p className="text-muted-foreground font-body text-sm">
          Venture into the unknown dimension
        </p>
      </motion.div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <GlowingInput
          type="text"
          placeholder="Enter your registration number"
          label="College Registration Number"
          icon={<IdCard size={20} />}
          value={registrationNumber}
          onChange={(e) => setRegistrationNumber(e.target.value)}
          required
        />

        <GlowingInput
          type="email"
          placeholder="your.email@college.edu"
          label="Email Address"
          icon={<Mail size={20} />}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <GlowingInput
          type="password"
          placeholder="••••••••••••"
          label="Secret Password"
          icon={<KeyRound size={20} />}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <motion.button
          type="submit"
          disabled={isLoading}
          className="submit-btn w-full h-14 rounded-lg font-body font-semibold text-primary-foreground relative overflow-hidden mt-6"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          {isLoading ? (
            <motion.div
              className="flex items-center justify-center gap-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <motion.div
                className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full"
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              />
              <span>Opening the Rift...</span>
            </motion.div>
          ) : (
            "Enter the Upside Down"
          )}
        </motion.button>
      </form>

      {/* Divider */}
      <div className="relative my-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border/30" />
        </div>
        <div className="relative flex justify-center">
          <span className="bg-transparent px-4 text-sm text-muted-foreground font-body">
            or continue with
          </span>
        </div>
      </div>

      {/* Google Sign In */}
      <GoogleSignInButton onClick={handleGoogleSignIn} isLoading={isLoading} />

      {/* Footer */}
      <motion.p
        className="text-center text-xs text-muted-foreground mt-6 font-body"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
      >
        By entering, you accept the laws of the Upside Down
      </motion.p>
    </motion.div>
  );
};
