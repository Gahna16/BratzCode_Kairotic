import { motion } from "framer-motion";
import { Compass, Map, Users, Shield, LogOut } from "lucide-react";

interface DashboardProps {
  onLogout: () => void;
}

export const Dashboard = ({ onLogout }: DashboardProps) => {
  const menuItems = [
    { icon: Compass, label: "Explore", description: "Discover new quests" },
    { icon: Map, label: "Journey", description: "Track your progress" },
    { icon: Users, label: "Party", description: "Find fellow travelers" },
    { icon: Shield, label: "Inventory", description: "Your collected items" },
  ];

  return (
    <div className="min-h-screen bg-background p-8">
      <motion.div
        className="max-w-4xl mx-auto"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <motion.h1
            className="text-4xl font-display font-bold title-glow text-primary"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            Welcome, Traveler
          </motion.h1>
          <motion.button
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-muted/50 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors font-body"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <LogOut size={18} />
            <span>Exit</span>
          </motion.button>
        </div>

        {/* Status Card */}
        <motion.div
          className="glass-card rounded-2xl p-6 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h2 className="text-xl font-display font-semibold text-foreground mb-4">
            Your <span className="text-gradient-fire">Quest Status</span>
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-3xl font-bold text-secondary">12</p>
              <p className="text-sm text-muted-foreground">Quests Complete</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-primary">Level 7</p>
              <p className="text-sm text-muted-foreground">Current Rank</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-accent">2,450</p>
              <p className="text-sm text-muted-foreground">XP Earned</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-foreground">3</p>
              <p className="text-sm text-muted-foreground">Party Members</p>
            </div>
          </div>
        </motion.div>

        {/* Menu Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {menuItems.map((item, index) => (
            <motion.button
              key={item.label}
              className="glass-card rounded-xl p-6 text-left hover:border-secondary/60 transition-all group"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.1 }}
              whileHover={{ scale: 1.02, y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-secondary/20 flex items-center justify-center group-hover:bg-secondary/30 transition-colors">
                  <item.icon className="text-secondary icon-glow" size={24} />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-foreground text-lg">
                    {item.label}
                  </h3>
                  <p className="text-sm text-muted-foreground font-body">
                    {item.description}
                  </p>
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      </motion.div>
    </div>
  );
};
