import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

interface RiftTransitionProps {
  isOpen: boolean;
  onComplete?: () => void;
  children: React.ReactNode;
}

export const RiftTransition = ({ isOpen, onComplete, children }: RiftTransitionProps) => {
  const [showContent, setShowContent] = useState(false);
  const [showEmbers, setShowEmbers] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setShowEmbers(true);
      const timer = setTimeout(() => {
        setShowContent(true);
        onComplete?.();
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [isOpen, onComplete]);

  // Generate rift embers
  const riftEmbers = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    x: 40 + Math.random() * 20,
    delay: Math.random() * 0.5,
  }));

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div className="fixed inset-0 z-50 overflow-hidden">
          {/* Top half sliding up */}
          <motion.div
            className="absolute inset-x-0 top-0 h-1/2 bg-background overflow-hidden"
            initial={{ y: 0 }}
            animate={{ y: "-100%" }}
            transition={{ duration: 1, ease: [0.76, 0, 0.24, 1], delay: 0.3 }}
            style={{ 
              boxShadow: "0 10px 100px hsl(35 100% 60% / 0.8)",
            }}
          >
            <div 
              className="absolute bottom-0 left-0 right-0 h-8"
              style={{
                background: "linear-gradient(to top, hsl(35 100% 50% / 0.8), transparent)",
              }}
            />
          </motion.div>

          {/* Bottom half sliding down */}
          <motion.div
            className="absolute inset-x-0 bottom-0 h-1/2 bg-background overflow-hidden"
            initial={{ y: 0 }}
            animate={{ y: "100%" }}
            transition={{ duration: 1, ease: [0.76, 0, 0.24, 1], delay: 0.3 }}
            style={{ 
              boxShadow: "0 -10px 100px hsl(35 100% 60% / 0.8)",
            }}
          >
            <div 
              className="absolute top-0 left-0 right-0 h-8"
              style={{
                background: "linear-gradient(to bottom, hsl(35 100% 50% / 0.8), transparent)",
              }}
            />
          </motion.div>

          {/* Center rift glow */}
          <motion.div
            className="absolute left-0 right-0 h-4 top-1/2 -translate-y-1/2"
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ scaleX: 1, opacity: [0, 1, 1, 0] }}
            transition={{ duration: 1.3, times: [0, 0.2, 0.8, 1] }}
            style={{
              background: "linear-gradient(to bottom, transparent, hsl(45 100% 70%), hsl(25 100% 55%), hsl(0 80% 50%), transparent)",
              boxShadow: "0 0 60px hsl(35 100% 60%), 0 0 120px hsl(25 100% 55%), 0 0 180px hsl(0 80% 50%)",
            }}
          />

          {/* Rift embers bursting out */}
          {showEmbers && riftEmbers.map((ember) => (
            <motion.div
              key={ember.id}
              className="absolute w-3 h-3 rounded-full"
              style={{
                left: `${ember.x}%`,
                top: "50%",
                background: "radial-gradient(circle, hsl(45 100% 70%) 0%, hsl(25 100% 55%) 50%, transparent 70%)",
                boxShadow: "0 0 10px hsl(35 100% 60%)",
              }}
              initial={{ scale: 0, x: 0, y: 0 }}
              animate={{
                scale: [0, 1.5, 0],
                x: (Math.random() - 0.5) * 400,
                y: (Math.random() - 0.5) * 400,
                opacity: [0, 1, 0],
              }}
              transition={{
                duration: 1,
                delay: ember.delay,
                ease: "easeOut",
              }}
            />
          ))}

          {/* Content revealed */}
          <motion.div
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: showContent ? 1 : 0 }}
            transition={{ duration: 0.5 }}
          >
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
