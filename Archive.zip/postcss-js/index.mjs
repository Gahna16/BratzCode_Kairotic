import index from './index.js'

export default index

export const objectify = index.objectify
export const parse = index.parse
export const async = index.async
export const sync = index.sync
