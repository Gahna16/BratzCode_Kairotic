/** @private */
export function isValidDate(day: Date): boolean {
  return !isNaN(day.getTime());
}
