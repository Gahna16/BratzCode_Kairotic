import { labelMonthDropdown } from './labelMonthDropdown';

test('should return the label', () => {
  expect(labelMonthDropdown()).toEqual('Month: ');
});
