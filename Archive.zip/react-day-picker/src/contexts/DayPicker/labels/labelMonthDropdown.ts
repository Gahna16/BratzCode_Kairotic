/**
 * The default ARIA label for the WeekNumber element.
 */
export const labelMonthDropdown = (): string => {
  return 'Month: ';
};
