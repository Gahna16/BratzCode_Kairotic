import { Props as CartesianAxisProps } from './CartesianAxis';
export type Sign = 0 | 1 | -1;
export declare function getTicks(props: CartesianAxisProps, fontSize?: string, letterSpacing?: string): any[];
