export declare const warn: (condition: boolean, format: string, ...args: any[]) => void;
