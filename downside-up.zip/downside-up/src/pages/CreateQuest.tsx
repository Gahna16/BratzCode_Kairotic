import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin } from 'lucide-react';
import MainLayout from '@/components/MainLayout';
import DemogorgonModal from '@/components/DemogorgonModal';
import { useApp } from '@/contexts/AppContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const VIBE_TAGS = ['Chill', 'Active', 'Late Night', 'Food', 'Study', 'Adventure', 'Social', 'Outdoor'];

const CreateQuest: React.FC = () => {
  const navigate = useNavigate();
  const { createQuest } = useApp();
  const [showDemogorgon, setShowDemogorgon] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    activity: 'Food',
    time: '',
    date: '',
    venue: '',
    partySize: 4,
    vibeTags: [] as string[],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowDemogorgon(true);
  };

  const handleQuestCreated = () => {
    createQuest({
      title: formData.title,
      activity: formData.activity,
      time: `${formData.date} ${formData.time}`,
      venue: formData.venue,
      partySize: formData.partySize,
    });
    setShowDemogorgon(false);
    navigate('/');
  };

  const toggleVibe = (tag: string) => {
    setFormData(prev => ({
      ...prev,
      vibeTags: prev.vibeTags.includes(tag)
        ? prev.vibeTags.filter(t => t !== tag)
        : [...prev.vibeTags, tag],
    }));
  };

  return (
    <MainLayout showBackButton={true}>
      <div className="max-w-2xl mx-auto mt-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-8 neon-border-cyan"
        >
          <h2 className="font-stranger text-3xl text-center text-primary neon-red mb-8">
            CREATE YOUR QUEST
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title" className="font-body text-foreground">
                Quest Title
              </Label>
              <Input
                id="title"
                type="text"
                placeholder="Give your quest an epic name..."
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="bg-input/50 border-accent/50 focus:border-accent focus:ring-accent/50 h-12 neon-border-cyan"
                required
              />
            </div>

            <div className="space-y-2">
              <Label className="font-body text-foreground">Activity Type</Label>
              <Select
                value={formData.activity}
                onValueChange={(v) => setFormData({ ...formData, activity: v })}
              >
                <SelectTrigger className="bg-input/50 border-accent/50 focus:ring-accent/50 h-12">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Food">Food</SelectItem>
                  <SelectItem value="Study">Study</SelectItem>
                  <SelectItem value="Adventure">Adventure</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date" className="font-body text-foreground">
                  When
                </Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="bg-input/50 border-accent/50 focus:border-accent h-12"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="time" className="font-body text-foreground">
                  Time
                </Label>
                <Input
                  id="time"
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  className="bg-input/50 border-accent/50 focus:border-accent h-12"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="venue" className="font-body text-foreground">
                Where
              </Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-accent" />
                <Input
                  id="venue"
                  type="text"
                  placeholder="Meeting spot"
                  value={formData.venue}
                  onChange={(e) => setFormData({ ...formData, venue: e.target.value })}
                  className="pl-10 bg-input/50 border-accent/50 focus:border-accent h-12"
                  required
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <Label className="font-body text-foreground">Party Size (2–10)</Label>
                <span className="font-stranger text-xl text-accent neon-cyan">
                  {formData.partySize}
                </span>
              </div>
              <Slider
                value={[formData.partySize]}
                onValueChange={(v) => setFormData({ ...formData, partySize: v[0] })}
                min={2}
                max={10}
                step={1}
                className="py-4 [&_.bg-primary]:bg-accent"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-body text-foreground">Vibe Tags</Label>
              <div className="flex flex-wrap gap-2">
                {VIBE_TAGS.map(tag => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleVibe(tag)}
                    className={`px-4 py-2 rounded-full font-body text-sm border-2 transition-all ${
                      formData.vibeTags.includes(tag)
                        ? 'border-accent bg-accent/20 text-accent'
                        : 'border-muted bg-muted/30 text-muted-foreground hover:border-accent/50'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                type="submit"
                className="w-full h-16 mt-6 bg-primary hover:bg-primary/80 text-primary-foreground font-stranger text-xl tracking-wider pulse-glow-red transition-all"
              >
                OPEN THE GATE
              </Button>
            </motion.div>
          </form>
        </motion.div>
      </div>

      <DemogorgonModal
        isOpen={showDemogorgon}
        onClose={() => setShowDemogorgon(false)}
        onComplete={handleQuestCreated}
      />
    </MainLayout>
  );
};

export default CreateQuest;
