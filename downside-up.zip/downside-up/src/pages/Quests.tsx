import React from 'react';
import { motion } from 'framer-motion';
import { Plus, MapPin, Clock, Check } from 'lucide-react';
import MainLayout from '@/components/MainLayout';
import { useApp } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';

const Quests: React.FC = () => {
  const { quests, joinQuest } = useApp();
  const { toast } = useToast();

  const handleJoinQuest = (questId: string, questTitle: string) => {
    joinQuest(questId);
    toast({
      title: 'Quest Joined',
      description: `You've joined "${questTitle}".`,
      duration: 3000,
    });
  };

  return (
    <MainLayout showBackButton={true} backButtonHoverOnly={true}>
      <div className="max-w-4xl mx-auto mt-8">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-stranger text-3xl md:text-4xl text-center text-primary neon-red mb-8"
        >
          CURRENT QUESTS
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {quests.map((quest, index) => (
            <motion.div
              key={quest.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className={`glass-card p-6 border-2 relative overflow-hidden group ${
                quest.borderColor === 'yellow'
                  ? 'border-secondary neon-border-yellow'
                  : 'border-accent neon-border-cyan'
              }`}
            >
              {/* Quest Name - top, bold glowing white */}
              <h3 className="font-stranger text-xl text-foreground mb-4" style={{ textShadow: '0 0 15px rgba(255,255,255,0.6)' }}>
                {quest.title}
              </h3>

              {/* Date and Time - middle */}
              <div className="flex items-center gap-2 text-muted-foreground mb-4">
                <Clock className="w-4 h-4" />
                <span className="font-body text-sm">{quest.time}</span>
              </div>

              {/* Bottom row: Venue (left), Plus button (center), space (right) */}
              <div className="flex items-center justify-between gap-4 mt-6">
                <div className="flex items-center gap-2 text-muted-foreground min-w-0">
                  <MapPin className="w-4 h-4 shrink-0" />
                  <span className="font-body text-sm truncate">{quest.venue}</span>
                </div>

                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => handleJoinQuest(quest.id, quest.title)}
                  disabled={quest.joined}
                  className={`w-14 h-14 rounded-full flex items-center justify-center shrink-0 transition-all ${
                    quest.joined
                      ? 'bg-green-500/20 border-2 border-green-500 cursor-default'
                      : quest.borderColor === 'yellow'
                      ? 'bg-secondary/20 border-2 border-secondary hover:bg-secondary/40 neon-border-yellow'
                      : 'bg-accent/20 border-2 border-accent hover:bg-accent/40 neon-border-cyan'
                  }`}
                >
                  {quest.joined ? (
                    <Check className="w-7 h-7 text-green-500" />
                  ) : (
                    <Plus className={`w-7 h-7 ${quest.borderColor === 'yellow' ? 'text-secondary' : 'text-accent'}`} />
                  )}
                </motion.button>

                <div className="w-20 shrink-0" aria-hidden />
              </div>

              <div
                className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                  quest.borderColor === 'yellow'
                    ? 'bg-gradient-to-t from-secondary/10 to-transparent'
                    : 'bg-gradient-to-t from-accent/10 to-transparent'
                }`}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </MainLayout>
  );
};

export default Quests;
