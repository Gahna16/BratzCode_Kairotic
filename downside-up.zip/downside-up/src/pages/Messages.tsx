import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Hash, Users } from 'lucide-react';
import MainLayout from '@/components/MainLayout';
import { useApp } from '@/contexts/AppContext';
import { Input } from '@/components/ui/input';

const Messages: React.FC = () => {
  const { channels, sendMessage } = useApp();
  const [activeChannel, setActiveChannel] = useState(channels[0]?.id || '');
  const [messageInput, setMessageInput] = useState('');
  const [showSentPill, setShowSentPill] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentChannel = channels.find(c => c.id === activeChannel);
  const youMessages = currentChannel?.messages.filter(m => m.sender === 'YOU') ?? [];
  const lastYouMessageId = youMessages.length > 0 ? youMessages[youMessages.length - 1].id : null;

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentChannel?.messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || !activeChannel) return;

    sendMessage(activeChannel, messageInput.trim());
    setMessageInput('');
    setShowSentPill(true);
    setTimeout(() => setShowSentPill(false), 2500);
    scrollToBottom();
  };

  const channelDisplayName = (name: string) => {
    if (name === 'ARENA CLASHS') return 'ARENA CLASHERS';
    return name;
  };

  return (
    <MainLayout showBackButton={true}>
      <div className="max-w-5xl mx-auto mt-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card overflow-hidden h-[600px] flex border-2 border-accent/30"
        >
          {/* Left - ACTIVE CHANNELS, neon yellow border */}
          <div className="w-64 border-r-2 border-secondary/50 flex flex-col neon-border-yellow bg-card/30">
            <div className="p-4 border-b border-border">
              <h3 className="font-stranger text-lg text-primary neon-red">
                ACTIVE CHANNELS
              </h3>
            </div>
            <div className="flex-1 overflow-y-auto p-2">
              {channels.map((channel) => (
                <motion.button
                  key={channel.id}
                  whileHover={{ x: 4 }}
                  onClick={() => setActiveChannel(channel.id)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors text-left ${
                    activeChannel === channel.id
                      ? 'bg-secondary/20 border border-secondary/50'
                      : 'hover:bg-muted/50'
                  }`}
                >
                  <Hash className="w-5 h-5 text-secondary" />
                  <span className="font-body text-sm truncate text-foreground">
                    {channel.name}
                  </span>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Right - Chat window, neon blue border */}
          <div className="flex-1 flex flex-col border-l-2 border-accent/50 neon-border-cyan bg-card/20">
            <div className="p-4 border-b border-border">
              <h3 className="font-stranger text-lg text-accent neon-cyan">
                {currentChannel ? `${channelDisplayName(currentChannel.name)} - ${currentChannel.memberCount}/${currentChannel.maxPlayers} Players` : 'Select a channel'}
              </h3>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {currentChannel?.messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex flex-col gap-1"
                >
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`font-body text-sm font-semibold ${
                      message.sender === 'YOU' ? 'text-accent' : 'text-secondary'
                    }`}>
                      {message.sender}:
                    </span>
                    {message.sender === 'YOU' && showSentPill && lastYouMessageId === message.id && (
                      <span className="px-2 py-0.5 rounded-full text-xs font-body bg-green-500/30 text-green-400 border border-green-500/50">
                        MESSAGE SENT
                      </span>
                    )}
                  </div>
                  <p className="font-body text-foreground/90">"{message.content}"</p>
                </motion.div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSendMessage} className="p-4 border-t border-border">
              <div className="flex gap-2">
                <Input
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder="Send a transmision..."
                  className="flex-1 bg-input/50 border-2 border-accent/50 focus:border-accent focus:ring-accent/50 rounded-lg h-12"
                />
                <motion.button
                  type="submit"
                  disabled={!messageInput.trim()}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-12 h-12 rounded-lg flex items-center justify-center bg-accent/30 border-2 border-accent text-accent disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Plus className="w-6 h-6" />
                </motion.button>
              </div>
            </form>
          </div>
        </motion.div>
      </div>
    </MainLayout>
  );
};

export default Messages;
