import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Award, MessageCircle, Sword, Shield, Bell, Compass, Zap } from 'lucide-react';
import MainLayout from '@/components/MainLayout';
import { useApp } from '@/contexts/AppContext';

const Index: React.FC = () => {
  const { user } = useApp();
  const myQuestsCount = 2;

  const sidebarLinks = [
    { icon: Sword, label: `My Quests (${myQuestsCount})`, path: '/create-quest' },
    { icon: Award, label: 'My Badges', path: '/badges' },
    { icon: MessageCircle, label: 'Messages', path: '/messages' },
  ];

  return (
    <MainLayout showBackButton={false}>
      {/* Top right: Shield, Bell, User avatar */}
      <div className="absolute top-6 right-4 md:right-8 flex items-center gap-3 z-30">
        <button className="w-10 h-10 rounded-full glass-card flex items-center justify-center border border-muted/50 hover:border-primary/50 hover:shadow-[0_0_15px_hsl(var(--neon-red)/0.3)] transition-all">
          <Shield className="w-5 h-5 text-foreground" />
        </button>
        <button className="w-10 h-10 rounded-full glass-card flex items-center justify-center border border-muted/50 hover:border-primary/50 hover:shadow-[0_0_15px_hsl(var(--neon-red)/0.3)] transition-all">
          <Bell className="w-5 h-5 text-foreground" />
        </button>
        <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-secondary/50 ring-2 ring-secondary/20 hover:ring-secondary/50 transition-all">
          <div className="w-10 h-10 bg-gradient-to-br from-accent to-primary flex items-center justify-center">
            <User className="w-5 h-5 text-primary-foreground" />
          </div>
        </button>
      </div>

      <div className="max-w-7xl mx-auto mt-8 flex flex-col lg:flex-row gap-8">
        {/* Left Sidebar - compact glassmorphism card */}
        <motion.aside
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="lg:w-72 shrink-0"
        >
          <div className="glass-card p-6 neon-border-yellow max-w-xs">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-secondary to-primary p-0.5 shrink-0">
                <div className="w-full h-full rounded-full bg-card flex items-center justify-center">
                  <User className="w-7 h-7 text-secondary" />
                </div>
              </div>
              <p className="font-tagline text-secondary neon-yellow">
                Welcome Back, {user.name}!
              </p>
            </div>

            <nav className="space-y-2">
              {sidebarLinks.map((link, index) => (
                <motion.div
                  key={link.path}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                >
                  <Link
                    to={link.path}
                    className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 border border-transparent hover:border-secondary/30 transition-all group"
                  >
                    <link.icon className="w-5 h-5 text-muted-foreground group-hover:text-secondary transition-colors" />
                    <span className="font-body text-foreground group-hover:text-secondary transition-colors">
                      {link.label}
                    </span>
                  </Link>
                </motion.div>
              ))}
            </nav>
          </div>
        </motion.aside>

        {/* Right - two large neon action buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="flex-1 flex flex-col md:flex-row gap-6"
        >
          <Link to="/quests" className="flex-1 group">
            <motion.div
              whileHover={{ scale: 1.02, boxShadow: '0 0 40px hsl(var(--neon-cyan) / 0.6), 0 0 80px hsl(var(--neon-cyan) / 0.3)' }}
              whileTap={{ scale: 0.98 }}
              className="h-full min-h-[280px] glass-card p-8 flex flex-col items-center justify-center text-center border-2 border-accent cursor-pointer pulse-glow-cyan transition-all"
            >
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Compass className="w-20 h-20 text-accent mb-6" />
              </motion.div>
              <h3 className="font-stranger text-3xl text-accent neon-cyan mb-2">
                JOIN A QUEST
              </h3>
              <p className="font-body text-muted-foreground text-sm max-w-xs">
                Find adventures and join the party
              </p>
            </motion.div>
          </Link>

          <Link to="/create-quest" className="flex-1 group">
            <motion.div
              whileHover={{ scale: 1.02, boxShadow: '0 0 40px hsl(var(--neon-red) / 0.6), 0 0 80px hsl(var(--neon-red) / 0.3)' }}
              whileTap={{ scale: 0.98 }}
              className="h-full min-h-[280px] glass-card p-8 flex flex-col items-center justify-center text-center border-2 border-primary cursor-pointer pulse-glow-red transition-all"
            >
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Zap className="w-20 h-20 text-primary mb-6" />
              </motion.div>
              <h3 className="font-stranger text-3xl text-primary neon-red mb-2">
                HOST A QUEST
              </h3>
              <p className="font-body text-muted-foreground text-sm max-w-xs">
                Create your own adventure
              </p>
            </motion.div>
          </Link>
        </motion.div>
      </div>
    </MainLayout>
  );
};

export default Index;
