import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Chrome } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import RiftTransition from '@/components/RiftTransition';
import AshParticles from '@/components/AshParticles';
import backgroundImage from '@/assets/background.jpeg';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const [isRiftActive, setIsRiftActive] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [formData, setFormData] = useState({
    collegeId: '',
    email: '',
    password: '',
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsRiftActive(true);
  };

  const handleGoogleClick = () => {
    setIsGoogleLoading(true);
    setTimeout(() => setIsRiftActive(true), 800);
  };

  const handleRiftComplete = () => {
    setTimeout(() => navigate('/'), 200);
  };

  return (
    <>
      <div className="min-h-screen relative overflow-hidden flex items-center justify-center">
        {/* Background - campus at night with overlay */}
        <div
          className="fixed inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url(${backgroundImage})`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/85 to-background/95" />
          <div
            className="absolute inset-0"
            style={{
              background:
                'radial-gradient(ellipse at center, transparent 0%, hsl(var(--background)) 80%)',
            }}
          />
          {/* Retro 80s film grain */}
          <div
            className="absolute inset-0 opacity-[0.03] pointer-events-none"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
            }}
          />
        </div>

        <AshParticles />

        {/* Branding - DOWNSIDE-UP (Benguiat/Stranger Things) + tagline */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.1 }}
          className="absolute top-8 text-center z-10"
        >
          <h1 className="font-stranger text-5xl md:text-7xl text-primary neon-red-heavy flicker tracking-wider">
            DOWNSIDE-UP
          </h1>
          <div className="mt-1 h-1 w-32 mx-auto bg-primary rounded-full opacity-90" style={{ boxShadow: '0 0 15px hsl(var(--neon-red))' }} />
          <p className="mt-3 text-xl md:text-2xl font-tagline text-secondary neon-yellow italic">
            Ditch the scroll. Unlock the Quest.
          </p>
        </motion.div>

        {/* Login Card - glassmorphism */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="relative z-20 w-full max-w-md mx-4"
        >
          <div className="glass-card p-8 neon-border-red">
            {/* Google Button */}
            <Button
              type="button"
              variant="outline"
              className="w-full mb-6 h-12 border-muted hover:border-accent hover:bg-accent/10 hover:shadow-[0_0_20px_rgba(255,255,255,0.15)] transition-all"
              onClick={handleGoogleClick}
              disabled={isGoogleLoading}
            >
              {isGoogleLoading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full"
                />
              ) : (
                <>
                  <Chrome className="w-5 h-5 mr-3" />
                  <span className="font-body">Sign in with Google</span>
                </>
              )}
            </Button>

            <div className="relative mb-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-muted" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-card text-muted-foreground font-body">or</span>
              </div>
            </div>

            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="collegeId" className="font-body text-foreground">
                  College Registration Number
                </Label>
                <Input
                  id="collegeId"
                  type="text"
                  placeholder="e.g. ST-2024-001"
                  value={formData.collegeId}
                  onChange={(e) => setFormData({ ...formData, collegeId: e.target.value })}
                  className="bg-transparent border-0 border-b-2 border-muted rounded-none focus-visible:ring-0 focus-visible:border-primary focus-visible:shadow-[0_0_10px_hsl(var(--neon-red)/0.5)] text-white h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="font-body text-foreground">
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@college.edu"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-transparent border-0 border-b-2 border-muted rounded-none focus-visible:ring-0 focus-visible:border-primary focus-visible:shadow-[0_0_10px_hsl(var(--neon-red)/0.5)] text-white h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="font-body text-foreground">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="bg-transparent border-0 border-b-2 border-muted rounded-none focus-visible:ring-0 focus-visible:border-primary focus-visible:shadow-[0_0_10px_hsl(var(--neon-red)/0.5)] text-white h-12"
                />
              </div>

              <Button
                type="submit"
                className="w-full h-14 mt-4 bg-primary hover:bg-primary/80 text-primary-foreground font-stranger text-lg tracking-wider pulse-glow-red transition-all"
              >
                Sign Up
              </Button>
            </form>

            <div className="mt-6 flex flex-col items-center gap-2 text-sm">
              <a href="#" className="font-body text-muted-foreground hover:text-primary transition-colors">
                Forgot password?
              </a>
              <a href="#" className="font-body text-muted-foreground hover:text-primary transition-colors">
                Already have an account? Login
              </a>
            </div>
          </div>
        </motion.div>
      </div>

      <RiftTransition isActive={isRiftActive} onComplete={handleRiftComplete} />
    </>
  );
};

export default Login;
