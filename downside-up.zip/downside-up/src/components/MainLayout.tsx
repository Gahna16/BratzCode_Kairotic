import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import AshParticles from './AshParticles';
import backgroundImage from '@/assets/background.jpeg';

interface MainLayoutProps {
  children: React.ReactNode;
  showBackButton?: boolean;
  /** When true, back button only appears on hover near top-left (e.g. Quests page) */
  backButtonHoverOnly?: boolean;
}

const MainLayout: React.FC<MainLayoutProps> = ({
  children,
  showBackButton = true,
  backButtonHoverOnly = false,
}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === '/';
  const [hoverTopLeft, setHoverTopLeft] = useState(false);

  const handleBack = () => {
    navigate('/');
  };

  const showBack = showBackButton && !isHome && (backButtonHoverOnly ? hoverTopLeft : true);

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background - Campus map with overlay */}
      <div
        className="fixed inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${backgroundImage})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/85 to-background/95" />
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse at center, transparent 0%, hsl(var(--background)) 80%)',
          }}
        />
      </div>

      <AshParticles />

      <div className="relative z-20 min-h-screen flex flex-col">
        {/* Top-left hover zone for back button (Quests page) */}
        {backButtonHoverOnly && (
          <div
            className="absolute left-0 top-0 w-32 h-24 z-30"
            onMouseEnter={() => setHoverTopLeft(true)}
            onMouseLeave={() => setHoverTopLeft(false)}
            aria-hidden
          />
        )}

        <header className="relative pt-6 pb-4 px-4">
          {showBack && (
            <motion.button
              initial={{ opacity: backButtonHoverOnly ? 0 : 1 }}
              animate={{ opacity: 1 }}
              onClick={handleBack}
              className={`rounded-full glass-card hover:bg-muted/50 transition-colors group ${
                backButtonHoverOnly
                  ? 'absolute left-4 top-6 p-2 floating-back'
                  : 'absolute left-4 top-6 p-2'
              }`}
            >
              <ArrowLeft className="w-6 h-6 text-foreground group-hover:text-primary transition-colors" />
            </motion.button>
          )}

          {/* Branding - DOWNSIDE-UP + tagline, same font on all pages */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="font-stranger text-4xl md:text-6xl text-primary neon-red-heavy flicker tracking-wider">
              DOWNSIDE-UP
            </h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="mt-2 text-lg md:text-xl font-tagline text-secondary neon-yellow italic"
            >
              Ditch the scroll. Unlock the Quest.
            </motion.p>
          </motion.div>
        </header>

        <main className="flex-1 px-4 pb-8">{children}</main>
      </div>
    </div>
  );
};

export default MainLayout;
