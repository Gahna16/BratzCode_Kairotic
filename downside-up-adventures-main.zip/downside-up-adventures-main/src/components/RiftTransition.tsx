import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface RiftTransitionProps {
  isActive: boolean;
  onComplete: () => void;
}

const RiftTransition: React.FC<RiftTransitionProps> = ({ isActive, onComplete }) => {
  return (
    <AnimatePresence>
      {isActive && (
        <div className="fixed inset-0 z-[100] overflow-hidden">
          {/* Fiery background revealed behind */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0 bg-gradient-to-b from-orange-600 via-red-700 to-red-900"
          >
            {/* Fire particles effect */}
            <div className="absolute inset-0">
              {Array.from({ length: 30 }).map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-2 h-2 rounded-full bg-orange-400"
                  initial={{ 
                    x: Math.random() * window.innerWidth, 
                    y: window.innerHeight + 50,
                    opacity: 0.8 
                  }}
                  animate={{ 
                    y: -50,
                    opacity: 0 
                  }}
                  transition={{ 
                    duration: 1.5 + Math.random(), 
                    repeat: Infinity,
                    delay: Math.random() * 0.5 
                  }}
                />
              ))}
            </div>
          </motion.div>

          {/* Top half of screen */}
          <motion.div
            initial={{ y: 0 }}
            animate={{ y: '-100%' }}
            transition={{ duration: 0.8, ease: [0.65, 0, 0.35, 1] }}
            onAnimationComplete={onComplete}
            className="absolute top-0 left-0 right-0 h-1/2 bg-background overflow-hidden"
          >
            {/* Jagged edge effect */}
            <div className="absolute bottom-0 left-0 right-0 h-8">
              <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 10">
                <path
                  d="M0,0 L5,10 L10,2 L15,8 L20,1 L25,9 L30,3 L35,7 L40,0 L45,10 L50,2 L55,8 L60,1 L65,9 L70,3 L75,7 L80,0 L85,10 L90,2 L95,8 L100,0 L100,10 L0,10 Z"
                  fill="hsl(var(--neon-red))"
                  className="drop-shadow-[0_0_10px_hsl(var(--neon-red))]"
                />
              </svg>
            </div>
          </motion.div>

          {/* Bottom half of screen */}
          <motion.div
            initial={{ y: 0 }}
            animate={{ y: '100%' }}
            transition={{ duration: 0.8, ease: [0.65, 0, 0.35, 1] }}
            className="absolute bottom-0 left-0 right-0 h-1/2 bg-background overflow-hidden"
          >
            {/* Jagged edge effect */}
            <div className="absolute top-0 left-0 right-0 h-8">
              <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 10">
                <path
                  d="M0,10 L5,0 L10,8 L15,2 L20,9 L25,1 L30,7 L35,3 L40,10 L45,0 L50,8 L55,2 L60,9 L65,1 L70,7 L75,3 L80,10 L85,0 L90,8 L95,2 L100,10 L100,0 L0,0 Z"
                  fill="hsl(var(--neon-red))"
                  className="drop-shadow-[0_0_10px_hsl(var(--neon-red))]"
                />
              </svg>
            </div>
          </motion.div>

          {/* Center glow line */}
          <motion.div
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ scaleX: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="absolute top-1/2 left-0 right-0 h-1 bg-neon-red origin-center"
            style={{
              boxShadow: '0 0 20px hsl(var(--neon-red)), 0 0 40px hsl(var(--neon-red)), 0 0 60px hsl(var(--neon-orange))',
            }}
          />
        </div>
      )}
    </AnimatePresence>
  );
};

export default RiftTransition;
