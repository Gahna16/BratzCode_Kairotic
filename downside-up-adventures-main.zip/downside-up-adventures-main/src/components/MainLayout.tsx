import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import AshParticles from './AshParticles';
import backgroundImage from '@/assets/background.jpeg';

interface MainLayoutProps {
  children: React.ReactNode;
  showBackButton?: boolean;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children, showBackButton = true }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === '/';

  const handleBack = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background - Campus map with overlay */}
      <div 
        className="fixed inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${backgroundImage})`,
        }}
      >
        {/* Dark overlay with vignette */}
        <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/85 to-background/95" />
        <div 
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse at center, transparent 0%, hsl(var(--background)) 80%)',
          }}
        />
      </div>

      {/* Ash Particles */}
      <AshParticles />

      {/* Content Container */}
      <div className="relative z-20 min-h-screen flex flex-col">
        {/* Header */}
        <header className="relative pt-6 pb-4 px-4">
          {/* Back Button */}
          {showBackButton && !isHome && (
            <button
              onClick={handleBack}
              className="absolute left-4 top-6 p-2 rounded-full glass-card hover:bg-muted/50 transition-colors group"
            >
              <ArrowLeft className="w-6 h-6 text-foreground group-hover:text-primary transition-colors" />
            </button>
          )}

          {/* Branding */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="font-stranger text-4xl md:text-6xl text-primary neon-red flicker tracking-wider">
              DOWNSIDE-UP
            </h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="mt-2 text-lg md:text-xl font-body text-secondary neon-yellow italic"
            >
              Ditch the scroll. Unlock the Quest.
            </motion.p>
          </motion.div>
        </header>

        {/* Main Content */}
        <main className="flex-1 px-4 pb-8">
          {children}
        </main>
      </div>
    </div>
  );
};

export default MainLayout;
