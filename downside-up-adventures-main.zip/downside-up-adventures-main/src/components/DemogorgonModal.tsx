import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface DemogorgonModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

const DemogorgonModal: React.FC<DemogorgonModalProps> = ({ isOpen, onClose, onComplete }) => {
  const [showMessage, setShowMessage] = useState(false);
  const petals = 6;

  useEffect(() => {
    if (isOpen) {
      const messageTimer = setTimeout(() => setShowMessage(true), 600);
      const closeTimer = setTimeout(() => {
        onComplete();
        onClose();
      }, 3000);

      return () => {
        clearTimeout(messageTimer);
        clearTimeout(closeTimer);
      };
    } else {
      setShowMessage(false);
    }
  }, [isOpen, onClose, onComplete]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80"
        >
          {/* Demogorgon Mouth Container */}
          <div className="relative w-80 h-80">
            {/* Petals */}
            {Array.from({ length: petals }).map((_, i) => {
              const rotation = (360 / petals) * i;
              return (
                <motion.div
                  key={i}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{
                    duration: 0.5,
                    delay: i * 0.08,
                    ease: [0.34, 1.56, 0.64, 1],
                  }}
                  className="absolute top-1/2 left-1/2 origin-bottom"
                  style={{
                    transform: `translate(-50%, -100%) rotate(${rotation}deg)`,
                    width: '60px',
                    height: '140px',
                  }}
                >
                  {/* Petal shape using clip-path */}
                  <div
                    className="w-full h-full bg-gradient-to-t from-red-950 via-red-800 to-red-600"
                    style={{
                      clipPath: 'polygon(50% 0%, 100% 100%, 50% 85%, 0% 100%)',
                      boxShadow: 'inset 0 0 20px rgba(0,0,0,0.8)',
                    }}
                  >
                    {/* Vein texture */}
                    <div className="absolute inset-0 opacity-40">
                      <div className="absolute left-1/2 top-0 w-0.5 h-3/4 bg-red-950 transform -translate-x-1/2" />
                      <div className="absolute left-1/4 top-1/4 w-0.5 h-1/2 bg-red-950 rotate-12" />
                      <div className="absolute right-1/4 top-1/4 w-0.5 h-1/2 bg-red-950 -rotate-12" />
                    </div>
                  </div>
                  
                  {/* Outer edge glow */}
                  <motion.div
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                    className="absolute inset-0"
                    style={{
                      clipPath: 'polygon(50% 0%, 100% 100%, 50% 85%, 0% 100%)',
                      boxShadow: '0 0 15px hsl(var(--neon-red)), 0 0 30px hsl(var(--neon-red) / 0.5)',
                    }}
                  />
                </motion.div>
              );
            })}

            {/* Center void/mouth */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.4, duration: 0.3 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full bg-black"
              style={{
                boxShadow: 'inset 0 0 30px rgba(139, 0, 0, 0.8), 0 0 40px rgba(0, 0, 0, 0.8)',
              }}
            >
              {/* Inner glow */}
              <motion.div
                animate={{ opacity: [0.3, 0.7, 0.3] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-2 rounded-full bg-gradient-radial from-red-900/50 to-transparent"
              />
            </motion.div>

            {/* Success Message */}
            <AnimatePresence>
              {showMessage && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.5 }}
                  className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center z-10"
                >
                  <h2 className="font-stranger text-2xl text-primary neon-red whitespace-nowrap">
                    QUEST CREATED
                  </h2>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Outer atmospheric glow */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'radial-gradient(circle at center, hsl(var(--neon-red) / 0.2) 0%, transparent 50%)',
            }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default DemogorgonModal;
