import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Chrome } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import RiftTransition from '@/components/RiftTransition';
import AshParticles from '@/components/AshParticles';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const [isRiftActive, setIsRiftActive] = useState(false);
  const [formData, setFormData] = useState({
    collegeId: '',
    email: '',
    password: '',
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsRiftActive(true);
  };

  const handleRiftComplete = () => {
    setTimeout(() => {
      navigate('/');
    }, 200);
  };

  return (
    <>
      <div className="min-h-screen relative overflow-hidden flex items-center justify-center">
        {/* Background */}
        <div 
          className="fixed inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1562774053-701939374585?w=1920&q=80')`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/85 to-background/95" />
          <div 
            className="absolute inset-0"
            style={{
              background: 'radial-gradient(ellipse at center, transparent 0%, hsl(var(--background)) 80%)',
            }}
          />
        </div>

        <AshParticles />

        {/* Branding */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="absolute top-8 text-center z-10"
        >
          <h1 className="font-stranger text-5xl md:text-7xl text-primary neon-red flicker tracking-wider">
            DOWNSIDE-UP
          </h1>
          <p className="mt-3 text-xl md:text-2xl font-body text-secondary neon-yellow italic">
            Ditch the scroll. Unlock the Quest.
          </p>
        </motion.div>

        {/* Login Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="relative z-20 w-full max-w-md mx-4"
        >
          <div className="glass-card p-8 neon-border-red">
            <h2 className="font-stranger text-2xl text-center text-foreground mb-8">
              Enter The Gate
            </h2>

            {/* Google Auth Button */}
            <Button
              type="button"
              variant="outline"
              className="w-full mb-6 h-12 border-muted hover:border-accent hover:bg-accent/10 transition-all"
              onClick={() => setIsRiftActive(true)}
            >
              <Chrome className="w-5 h-5 mr-3" />
              <span className="font-body">Continue with Google</span>
            </Button>

            <div className="relative mb-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-muted" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-card text-muted-foreground font-body">or</span>
              </div>
            </div>

            {/* Login Form */}
            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="collegeId" className="font-body text-foreground">
                  College ID
                </Label>
                <Input
                  id="collegeId"
                  type="text"
                  placeholder="ST-2024-001"
                  value={formData.collegeId}
                  onChange={(e) => setFormData({ ...formData, collegeId: e.target.value })}
                  className="bg-input/50 border-muted focus:border-primary focus:ring-primary/50 h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="font-body text-foreground">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@college.edu"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-input/50 border-muted focus:border-primary focus:ring-primary/50 h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="font-body text-foreground">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="bg-input/50 border-muted focus:border-primary focus:ring-primary/50 h-12"
                />
              </div>

              <Button
                type="submit"
                className="w-full h-14 mt-4 bg-primary hover:bg-primary/80 text-primary-foreground font-stranger text-lg tracking-wider pulse-glow-red transition-all"
              >
                OPEN THE GATE
              </Button>
            </form>
          </div>
        </motion.div>
      </div>

      {/* Rift Transition */}
      <RiftTransition isActive={isRiftActive} onComplete={handleRiftComplete} />
    </>
  );
};

export default Login;
