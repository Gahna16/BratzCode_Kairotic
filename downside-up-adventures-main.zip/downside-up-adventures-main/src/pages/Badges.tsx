import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, X, Sparkles, Heart, Compass, Crown, Cookie, Laugh } from 'lucide-react';
import MainLayout from '@/components/MainLayout';
import { useApp } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';

const badges = [
  { name: 'The Comedian', icon: Laugh, color: 'text-secondary' },
  { name: 'The Mom', icon: Heart, color: 'text-primary' },
  { name: 'Kind Core', icon: Sparkles, color: 'text-accent' },
  { name: 'The Navigator', icon: Compass, color: 'text-secondary' },
  { name: 'Quest Leader', icon: Crown, color: 'text-primary' },
  { name: 'Snack Master', icon: Cookie, color: 'text-accent' },
];

const Badges: React.FC = () => {
  const { profiles, assignBadge, removeProfile } = useApp();
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  const handleBadgeSelect = (profileId: string, badge: typeof badges[0]) => {
    assignBadge(profileId, badge.name, badge.color);
    setOpenDropdown(null);
  };

  const handleRemoveProfile = (profileId: string) => {
    removeProfile(profileId);
  };

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto mt-8">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-stranger text-3xl text-center text-foreground mb-8"
        >
          Assign Badges
        </motion.h2>

        {/* Profile Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {profiles.map((profile, index) => (
              <motion.div
                key={profile.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8, y: 20 }}
                transition={{ delay: index * 0.1 }}
                className="glass-card p-6 relative"
              >
                {/* Profile Avatar */}
                <div className="flex flex-col items-center mb-4">
                  <div className="relative">
                    <img
                      src={profile.avatar}
                      alt={profile.name}
                      className="w-24 h-24 rounded-full border-2 border-accent/50"
                    />
                    
                    {/* Badge Icon Display */}
                    {profile.badge && profile.badgeIcon && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className={`absolute -bottom-2 -right-2 w-10 h-10 rounded-full bg-card border-2 border-accent flex items-center justify-center ${profile.badgeIcon}`}
                      >
                        {badges.find(b => b.name === profile.badge)?.icon && (
                          React.createElement(
                            badges.find(b => b.name === profile.badge)!.icon,
                            { className: `w-5 h-5 ${profile.badgeIcon}` }
                          )
                        )}
                      </motion.div>
                    )}
                  </div>
                  
                  <h3 className="font-stranger text-lg text-foreground mt-4">
                    {profile.name}
                  </h3>
                  
                  {profile.badge && (
                    <motion.span
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className={`text-sm font-body ${profile.badgeIcon} mt-1`}
                    >
                      {profile.badge}
                    </motion.span>
                  )}
                </div>

                {/* Badge Selection Dropdown */}
                <div className="relative">
                  <Button
                    onClick={() => setOpenDropdown(openDropdown === profile.id ? null : profile.id)}
                    variant="outline"
                    className="w-full justify-between border-muted hover:border-accent"
                  >
                    <span className="font-body">
                      {profile.badge || 'Assign Badge'}
                    </span>
                    <ChevronDown 
                      className={`w-4 h-4 transition-transform ${
                        openDropdown === profile.id ? 'rotate-180' : ''
                      }`} 
                    />
                  </Button>

                  <AnimatePresence>
                    {openDropdown === profile.id && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="absolute top-full left-0 right-0 mt-2 z-50 glass-card border border-accent/30 overflow-hidden"
                      >
                        {badges.map((badge) => (
                          <button
                            key={badge.name}
                            onClick={() => handleBadgeSelect(profile.id, badge)}
                            className="w-full flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors text-left"
                          >
                            <badge.icon className={`w-5 h-5 ${badge.color}`} />
                            <span className={`font-body ${badge.color}`}>
                              {badge.name}
                            </span>
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Not Interested Button */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleRemoveProfile(profile.id)}
                  className="w-full mt-4 flex items-center justify-center gap-2 p-2 rounded-lg bg-destructive/20 border border-destructive/50 hover:bg-destructive/30 transition-colors group"
                >
                  <X className="w-4 h-4 text-destructive group-hover:text-destructive-foreground" />
                  <span className="font-body text-sm text-destructive group-hover:text-destructive-foreground">
                    Not Interested
                  </span>
                </motion.button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Empty State */}
        {profiles.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <p className="font-body text-muted-foreground text-xl">
              No profiles remaining. Check back later!
            </p>
          </motion.div>
        )}
      </div>
    </MainLayout>
  );
};

export default Badges;
