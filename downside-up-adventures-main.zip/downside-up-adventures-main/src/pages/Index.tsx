import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Award, MessageCircle, Compass, Zap } from 'lucide-react';
import MainLayout from '@/components/MainLayout';
import { useApp } from '@/contexts/AppContext';

const Index: React.FC = () => {
  const { user } = useApp();

  const sidebarLinks = [
    { icon: Compass, label: 'My Quests', path: '/create-quest' },
    { icon: Award, label: 'My Badges', path: '/badges' },
    { icon: MessageCircle, label: 'Messages', path: '/messages' },
  ];

  return (
    <MainLayout showBackButton={false}>
      <div className="max-w-7xl mx-auto mt-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left Sidebar - Profile Card */}
          <motion.aside
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:w-72 shrink-0"
          >
            <div className="glass-card p-6 neon-border-cyan">
              {/* Profile Header */}
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-primary p-0.5">
                  <div className="w-full h-full rounded-full bg-card flex items-center justify-center">
                    <User className="w-8 h-8 text-accent" />
                  </div>
                </div>
                <div>
                  <h2 className="font-stranger text-lg text-foreground">
                    Welcome Back,
                  </h2>
                  <p className="font-stranger text-xl text-accent neon-cyan">
                    {user.name}!
                  </p>
                </div>
              </div>

              {/* Navigation Links */}
              <nav className="space-y-3">
                {sidebarLinks.map((link, index) => (
                  <motion.div
                    key={link.path}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                  >
                    <Link
                      to={link.path}
                      className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 border border-transparent hover:border-accent/30 transition-all group"
                    >
                      <link.icon className="w-5 h-5 text-muted-foreground group-hover:text-accent transition-colors" />
                      <span className="font-body text-foreground group-hover:text-accent transition-colors">
                        {link.label}
                      </span>
                    </Link>
                  </motion.div>
                ))}
              </nav>
            </div>
          </motion.aside>

          {/* Right Side - Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex-1 flex flex-col md:flex-row gap-6"
          >
            {/* Join a Quest Button */}
            <Link to="/quests" className="flex-1 group">
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="h-full min-h-[300px] glass-card p-8 flex flex-col items-center justify-center text-center border-2 border-accent cursor-pointer pulse-glow-cyan transition-all"
              >
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Compass className="w-20 h-20 text-accent mb-6" />
                </motion.div>
                <h3 className="font-stranger text-3xl text-accent neon-cyan mb-3">
                  JOIN A QUEST
                </h3>
                <p className="font-body text-muted-foreground max-w-xs">
                  Find adventures happening around campus and join the party
                </p>
              </motion.div>
            </Link>

            {/* Host a Quest Button */}
            <Link to="/create-quest" className="flex-1 group">
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="h-full min-h-[300px] glass-card p-8 flex flex-col items-center justify-center text-center border-2 border-primary cursor-pointer pulse-glow-red transition-all"
              >
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Zap className="w-20 h-20 text-primary mb-6" />
                </motion.div>
                <h3 className="font-stranger text-3xl text-primary neon-red mb-3">
                  HOST A QUEST
                </h3>
                <p className="font-body text-muted-foreground max-w-xs">
                  Create your own adventure and invite others to join
                </p>
              </motion.div>
            </Link>
          </motion.div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Index;
