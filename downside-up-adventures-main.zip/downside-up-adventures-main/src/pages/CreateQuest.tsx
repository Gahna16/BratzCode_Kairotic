import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import MainLayout from '@/components/MainLayout';
import DemogorgonModal from '@/components/DemogorgonModal';
import { useApp } from '@/contexts/AppContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';

const CreateQuest: React.FC = () => {
  const navigate = useNavigate();
  const { createQuest } = useApp();
  const [showDemogorgon, setShowDemogorgon] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    activity: '',
    time: '',
    venue: '',
    partySize: 4,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowDemogorgon(true);
  };

  const handleQuestCreated = () => {
    createQuest(formData);
    navigate('/');
  };

  return (
    <MainLayout>
      <div className="max-w-2xl mx-auto mt-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-8 neon-border-cyan"
        >
          <h2 className="font-stranger text-3xl text-center text-foreground mb-8">
            Create Your Quest
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Title Input */}
            <div className="space-y-2">
              <Label htmlFor="title" className="font-body text-foreground">
                Quest Title
              </Label>
              <Input
                id="title"
                type="text"
                placeholder="Give your quest an epic name..."
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="bg-input/50 border-accent/50 focus:border-accent focus:ring-accent/50 h-12"
                required
              />
            </div>

            {/* Activity Input */}
            <div className="space-y-2">
              <Label htmlFor="activity" className="font-body text-foreground">
                Activity Description
              </Label>
              <Input
                id="activity"
                type="text"
                placeholder="What's the adventure about?"
                value={formData.activity}
                onChange={(e) => setFormData({ ...formData, activity: e.target.value })}
                className="bg-input/50 border-accent/50 focus:border-accent focus:ring-accent/50 h-12"
                required
              />
            </div>

            {/* Time Input */}
            <div className="space-y-2">
              <Label htmlFor="time" className="font-body text-foreground">
                Quest Time
              </Label>
              <Input
                id="time"
                type="text"
                placeholder="e.g., 8:00 PM"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className="bg-input/50 border-accent/50 focus:border-accent focus:ring-accent/50 h-12"
                required
              />
            </div>

            {/* Venue Input */}
            <div className="space-y-2">
              <Label htmlFor="venue" className="font-body text-foreground">
                Meeting Venue
              </Label>
              <Input
                id="venue"
                type="text"
                placeholder="Where does the adventure begin?"
                value={formData.venue}
                onChange={(e) => setFormData({ ...formData, venue: e.target.value })}
                className="bg-input/50 border-accent/50 focus:border-accent focus:ring-accent/50 h-12"
                required
              />
            </div>

            {/* Party Size Slider */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <Label className="font-body text-foreground">Party Size</Label>
                <span className="font-stranger text-xl text-accent neon-cyan">
                  {formData.partySize}
                </span>
              </div>
              <Slider
                value={[formData.partySize]}
                onValueChange={(value) => setFormData({ ...formData, partySize: value[0] })}
                min={2}
                max={10}
                step={1}
                className="py-4"
              />
              <div className="flex justify-between text-xs text-muted-foreground font-body">
                <span>2 adventurers</span>
                <span>10 adventurers</span>
              </div>
            </div>

            {/* Submit Button */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                type="submit"
                className="w-full h-16 mt-6 bg-primary hover:bg-primary/80 text-primary-foreground font-stranger text-xl tracking-wider pulse-glow-red transition-all"
              >
                OPEN THE GATE
              </Button>
            </motion.div>
          </form>
        </motion.div>
      </div>

      {/* Demogorgon Modal */}
      <DemogorgonModal
        isOpen={showDemogorgon}
        onClose={() => setShowDemogorgon(false)}
        onComplete={handleQuestCreated}
      />
    </MainLayout>
  );
};

export default CreateQuest;
