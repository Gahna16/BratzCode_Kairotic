import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Send, Hash, Users } from 'lucide-react';
import MainLayout from '@/components/MainLayout';
import { useApp } from '@/contexts/AppContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const Messages: React.FC = () => {
  const { channels, sendMessage, user } = useApp();
  const { toast } = useToast();
  const [activeChannel, setActiveChannel] = useState(channels[0]?.id || '');
  const [messageInput, setMessageInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentChannel = channels.find(c => c.id === activeChannel);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentChannel?.messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || !activeChannel) return;

    sendMessage(activeChannel, messageInput.trim());
    setMessageInput('');
    
    toast({
      title: "📡 MESSAGE SENT",
      description: "Your transmission has been delivered.",
      duration: 2000,
    });
  };

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto mt-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card overflow-hidden h-[600px] flex"
        >
          {/* Left Panel - Channels */}
          <div className="w-64 border-r border-border bg-card/50 flex flex-col">
            <div className="p-4 border-b border-border">
              <h3 className="font-stranger text-lg text-foreground">Channels</h3>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2">
              {channels.map((channel) => (
                <motion.button
                  key={channel.id}
                  whileHover={{ x: 4 }}
                  onClick={() => setActiveChannel(channel.id)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors text-left ${
                    activeChannel === channel.id
                      ? 'bg-accent/20 border border-accent/50'
                      : 'hover:bg-muted/50'
                  }`}
                >
                  <Hash className={`w-5 h-5 ${
                    activeChannel === channel.id ? 'text-accent' : 'text-muted-foreground'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className={`font-body text-sm truncate ${
                      activeChannel === channel.id ? 'text-accent' : 'text-foreground'
                    }`}>
                      {channel.name}
                    </p>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Users className="w-3 h-3" />
                      <span>{channel.members.length}</span>
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Right Panel - Messages */}
          <div className="flex-1 flex flex-col">
            {/* Channel Header */}
            <div className="p-4 border-b border-border flex items-center gap-3">
              <Hash className="w-6 h-6 text-accent" />
              <div>
                <h3 className="font-stranger text-lg text-foreground">
                  {currentChannel?.name || 'Select a channel'}
                </h3>
                <p className="text-xs text-muted-foreground font-body">
                  {currentChannel?.members.join(', ')}
                </p>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {currentChannel?.messages.map((message, index) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`flex gap-3 ${
                    message.sender === user.name ? 'flex-row-reverse' : ''
                  }`}
                >
                  {/* Avatar */}
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-stranger ${
                    message.sender === user.name 
                      ? 'bg-primary/30 text-primary'
                      : 'bg-accent/30 text-accent'
                  }`}>
                    {message.sender[0]}
                  </div>

                  {/* Message Bubble */}
                  <div className={`max-w-xs lg:max-w-md ${
                    message.sender === user.name ? 'text-right' : ''
                  }`}>
                    <div className="flex items-baseline gap-2 mb-1">
                      <span className={`font-body text-sm ${
                        message.sender === user.name ? 'text-primary' : 'text-accent'
                      }`}>
                        {message.sender}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {message.timestamp}
                      </span>
                    </div>
                    <div className={`p-3 rounded-lg font-body ${
                      message.sender === user.name
                        ? 'bg-primary/20 border border-primary/30'
                        : 'bg-muted/50 border border-muted'
                    }`}>
                      {message.content}
                    </div>
                  </div>
                </motion.div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-border">
              <div className="flex gap-3">
                <Input
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder="Send a transmission..."
                  className="flex-1 bg-input/50 border-muted focus:border-accent focus:ring-accent/50"
                />
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    type="submit"
                    className="bg-accent hover:bg-accent/80 text-accent-foreground"
                    disabled={!messageInput.trim()}
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </motion.div>
              </div>
            </form>
          </div>
        </motion.div>
      </div>
    </MainLayout>
  );
};

export default Messages;
