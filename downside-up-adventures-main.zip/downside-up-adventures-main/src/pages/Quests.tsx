import React from 'react';
import { motion } from 'framer-motion';
import { Plus, MapPin, Clock, Users, Check } from 'lucide-react';
import MainLayout from '@/components/MainLayout';
import { useApp } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';

const Quests: React.FC = () => {
  const { quests, joinQuest } = useApp();
  const { toast } = useToast();

  const handleJoinQuest = (questId: string, questTitle: string) => {
    joinQuest(questId);
    toast({
      title: "🎉 Quest Joined!",
      description: `You've joined "${questTitle}". Get ready for adventure!`,
      duration: 3000,
    });
  };

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto mt-8">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-stranger text-3xl text-center text-foreground mb-8"
        >
          Available Quests
        </motion.h2>

        {/* 2x2 Grid of Quest Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {quests.map((quest, index) => (
            <motion.div
              key={quest.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className={`glass-card p-6 border-2 ${
                quest.borderColor === 'yellow' 
                  ? 'border-secondary neon-border-yellow' 
                  : 'border-accent neon-border-cyan'
              } relative overflow-hidden group`}
            >
              {/* Quest Header */}
              <div className="flex justify-between items-start mb-4">
                <h3 
                  className={`font-stranger text-xl ${
                    quest.borderColor === 'yellow' ? 'text-secondary' : 'text-accent'
                  }`}
                >
                  {quest.title}
                </h3>
                
                {/* Join Button */}
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => handleJoinQuest(quest.id, quest.title)}
                  disabled={quest.joined}
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                    quest.joined
                      ? 'bg-green-500/20 border border-green-500 cursor-default'
                      : quest.borderColor === 'yellow'
                      ? 'bg-secondary/20 border border-secondary hover:bg-secondary/40'
                      : 'bg-accent/20 border border-accent hover:bg-accent/40'
                  }`}
                >
                  {quest.joined ? (
                    <Check className="w-5 h-5 text-green-500" />
                  ) : (
                    <Plus className={`w-5 h-5 ${
                      quest.borderColor === 'yellow' ? 'text-secondary' : 'text-accent'
                    }`} />
                  )}
                </motion.button>
              </div>

              {/* Quest Description */}
              <p className="font-body text-foreground/80 mb-4">
                {quest.activity}
              </p>

              {/* Quest Details */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span className="font-body text-sm">{quest.time}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span className="font-body text-sm">{quest.venue}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span className="font-body text-sm">Party of {quest.partySize}</span>
                </div>
              </div>

              {/* Joined Badge */}
              {quest.joined && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="absolute top-4 right-16 bg-green-500/20 border border-green-500 px-3 py-1 rounded-full"
                >
                  <span className="text-green-500 text-xs font-body">Joined</span>
                </motion.div>
              )}

              {/* Hover Glow Effect */}
              <div 
                className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                  quest.borderColor === 'yellow' 
                    ? 'bg-gradient-to-t from-secondary/10 to-transparent'
                    : 'bg-gradient-to-t from-accent/10 to-transparent'
                }`} 
              />
            </motion.div>
          ))}
        </div>
      </div>
    </MainLayout>
  );
};

export default Quests;
