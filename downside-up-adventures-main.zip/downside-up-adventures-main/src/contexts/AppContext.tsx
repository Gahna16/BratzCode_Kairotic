import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface Quest {
  id: string;
  title: string;
  activity: string;
  time: string;
  venue: string;
  partySize: number;
  joined: boolean;
  borderColor: 'yellow' | 'cyan';
}

export interface Profile {
  id: string;
  name: string;
  avatar: string;
  badge?: string;
  badgeIcon?: string;
}

export interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: string;
}

export interface Channel {
  id: string;
  name: string;
  members: string[];
  messages: Message[];
}

interface AppContextType {
  user: { name: string; collegeId: string };
  quests: Quest[];
  profiles: Profile[];
  channels: Channel[];
  joinQuest: (questId: string) => void;
  createQuest: (quest: Omit<Quest, 'id' | 'joined' | 'borderColor'>) => void;
  assignBadge: (profileId: string, badge: string, icon: string) => void;
  removeProfile: (profileId: string) => void;
  sendMessage: (channelId: string, content: string) => void;
}

const defaultQuests: Quest[] = [
  {
    id: '1',
    title: 'Midnight Pizza',
    activity: 'Late night pizza run to Dominos',
    time: '11:30 PM',
    venue: 'Main Gate',
    partySize: 4,
    joined: false,
    borderColor: 'yellow',
  },
  {
    id: '2',
    title: 'Beach Campfire',
    activity: 'Bonfire and ghost stories',
    time: '8:00 PM',
    venue: 'Juhu Beach',
    partySize: 8,
    joined: false,
    borderColor: 'cyan',
  },
  {
    id: '3',
    title: 'Movie Marathon',
    activity: 'Stranger Things Season 5 Watch Party',
    time: '6:00 PM',
    venue: 'Hostel Common Room',
    partySize: 6,
    joined: false,
    borderColor: 'cyan',
  },
  {
    id: '4',
    title: 'Night Trek',
    activity: 'Hiking to Kanheri Caves',
    time: '4:00 AM',
    venue: 'Campus Bus Stop',
    partySize: 10,
    joined: false,
    borderColor: 'yellow',
  },
];

const defaultProfiles: Profile[] = [
  { id: '1', name: 'Steve Harrington', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Steve' },
  { id: '2', name: 'Dustin Henderson', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Dustin' },
  { id: '3', name: 'Robin Buckley', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Robin' },
];

const defaultChannels: Channel[] = [
  {
    id: '1',
    name: 'Hawkins Squad',
    members: ['Steve', 'Dustin', 'Mike'],
    messages: [
      { id: '1', sender: 'Steve', content: 'Hey guys, ready for the quest tonight?', timestamp: '10:30 PM' },
      { id: '2', sender: 'Dustin', content: 'Absolutely! Got my walkie-talkie ready.', timestamp: '10:32 PM' },
      { id: '3', sender: 'Mike', content: 'Eleven said she might join us later.', timestamp: '10:35 PM' },
    ],
  },
  {
    id: '2',
    name: 'The Party',
    members: ['Mike', 'Lucas', 'Will'],
    messages: [
      { id: '1', sender: 'Mike', content: 'D&D session this weekend?', timestamp: '9:00 AM' },
      { id: '2', sender: 'Lucas', content: 'I call Paladin!', timestamp: '9:05 AM' },
    ],
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user] = useState({ name: 'Daniel', collegeId: 'ST-2024-001' });
  const [quests, setQuests] = useState<Quest[]>(defaultQuests);
  const [profiles, setProfiles] = useState<Profile[]>(defaultProfiles);
  const [channels, setChannels] = useState<Channel[]>(defaultChannels);

  const joinQuest = (questId: string) => {
    setQuests(prev =>
      prev.map(q => (q.id === questId ? { ...q, joined: true } : q))
    );
  };

  const createQuest = (quest: Omit<Quest, 'id' | 'joined' | 'borderColor'>) => {
    const newQuest: Quest = {
      ...quest,
      id: Date.now().toString(),
      joined: false,
      borderColor: Math.random() > 0.5 ? 'yellow' : 'cyan',
    };
    setQuests(prev => [newQuest, ...prev]);
  };

  const assignBadge = (profileId: string, badge: string, icon: string) => {
    setProfiles(prev =>
      prev.map(p => (p.id === profileId ? { ...p, badge, badgeIcon: icon } : p))
    );
  };

  const removeProfile = (profileId: string) => {
    setProfiles(prev => prev.filter(p => p.id !== profileId));
  };

  const sendMessage = (channelId: string, content: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      sender: user.name,
      content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setChannels(prev =>
      prev.map(c =>
        c.id === channelId ? { ...c, messages: [...c.messages, newMessage] } : c
      )
    );
  };

  return (
    <AppContext.Provider
      value={{
        user,
        quests,
        profiles,
        channels,
        joinQuest,
        createQuest,
        assignBadge,
        removeProfile,
        sendMessage,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
